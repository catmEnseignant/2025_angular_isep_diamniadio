import { Component } from '@angular/core';

@Component({
  selector: 'app-matieres',
  imports: [],
  templateUrl: './matieres.component.html',
  styleUrl: './matieres.component.css'
})
export class MatieresComponent {

}

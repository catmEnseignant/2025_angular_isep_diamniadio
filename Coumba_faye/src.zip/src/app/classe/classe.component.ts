import { Component } from '@angular/core';

@Component({
  selector: 'app-classe',
  imports: [],
  templateUrl: './classe.component.html',
  styleUrl: './classe.component.css'
})
export class ClasseComponent {

}
